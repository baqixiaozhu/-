package tse.tasks;


public class TestGoogleConstants {
    public static final String GOOGLE_SEARCH_BTN = "googleSearchBtn";
    public static final String GOOGLE_SEARCH_TXT_FIELD = "googleSearchTxtField";
    public static final String VERIFY_STRING = "verify-String";
}
