package tse.tasks;


public class TestBaiduConstants {
    public static final String BAIDU_SEARCH_BTN = "baiduSearchBtn";
    public static final String BAIDU_SEARCH_TXT_FIELD = "baiduSearchTxtField";
    public static final String VERIFY_STRING = "verify-String";
}
