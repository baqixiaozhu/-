package tse.tasks;


public class TestBingConstants {
    public static final String BING_SEARCH_BTN = "bingSearchBtn";
    public static final String BING_SEARCH_TXT_FIELD = "bingSearchTxtField";
    public static final String VERIFY_STRING = "verify-String";
}
